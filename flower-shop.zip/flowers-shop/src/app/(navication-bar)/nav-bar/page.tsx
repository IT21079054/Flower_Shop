import Link from "next/link";
import React from "react";
import { TiThMenu } from "react-icons/ti";

function NavBar() {
  return (
    <>
      <div className="flex justify-between items-center bg-slate-50 w-auto h-12 drop-shadow-md ">
        <div className="flex pl-5 items-center gap-3">
          <div className="">
            <TiThMenu />
          </div>
          <div className="">Flower Shop</div>
        </div>
        <div className="flex gap-6 pr-5 items-center ">
          <div className="">Flowers</div>
          <div className="">Plants</div>
          <div className="">Gifts</div>
          <div className="">Same Day</div>
          <div className="">Weddings</div>
          <div className="flex bg-[#18e719] rounded-lg w-14 h-8 justify-center items-center ">
            <div className="">Sign In</div>
          </div>
        </div>
      </div>
    </>
  );
}

export default NavBar;
