"use client";
import Image from "next/image";
import img from "../../public/images/home.jpg";
import { useState } from "react";
import { ToastContainer, toast } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";

export default function Home() {
  const [messageSent, setMessageSent] = useState(false);
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    phone: "",
    message: "",
  });

  const notify = () => toast("Please full fill!");

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFormData((prevData) => ({ ...prevData, [name]: value }));
    console.log("name", formData.name);
    console.log("email", formData.email);
    console.log("message", formData.message);
  };

  const handleSendMessage = () => {
    // if (!formData.name || !formData.email || !formData.message) {
    //   notify();
    //   return;
    // }
    setMessageSent(true);
  };

  return (
    <>
      <div className="flex justify-center mt-6 bg-[#f9fcf8]">
        <Image
          className="  rounded-lg w-auto"
          src={img}
          height={600}
          alt="Home Pic"
        />
        <div className="absolute bottom-1/3 transform translate-y-1/2 text-gray-100 pt-5\0 pl-10 ">
          <b>
            <h2 className="text-6xl">Beautiful flowers for every</h2>
            <h2 className="text-6xl mb-4">occasion</h2>
            <p className="max-w-5xl">
              We believe that flowers have the power to make any moment special.
              In our studeio. we take this to heart in everything we do. whether
              you are sending a bouquet town or arranging flowers for a special
              event,our passion for flowers shines through in our designs.
            </p>
          </b>
        </div>
      </div>
      <div className="flex justify-center mt-8 mb-5">
        <div className=" max-w-96 justify-center text-center border border-black-500">
          <h1 className="text-2xl mb-3">
            <b>Contacts Us</b>
          </h1>
          <p>
            We are here to help! Send us a massage and we will do our best to
            get back to you within 24 hours.
          </p>
        </div>
      </div>
      <div className="flex justify-center mt-8">
        <div className="w-96 h-auto border border-black-500 p-4">
          <form>
            <div className="mb-4">
              <label className="block text-gray-700 text-sm font-bold mb-2">
                Name:
              </label>
              <input
                className="bg-[#e8f3e9] rounded-lg p-2 w-full"
                type="text"
                name="name"
                value={formData.name}
                onChange={handleInputChange}
                placeholder="Your name"
                required
              />
            </div>
            <div className="mb-4">
              <label className="block text-gray-700 text-sm font-bold mb-2">
                Email:
              </label>
              <input
                className="bg-[#e8f3e9] rounded-lg p-2 w-full"
                type="email"
                name="email"
                value={formData.email}
                onChange={handleInputChange}
                placeholder="Your Email"
                required
              />
            </div>
            <div className="mb-4">
              <label className="block text-gray-700 text-sm font-bold mb-2">
                Phone (optional):
              </label>
              <input
                className="bg-[#e8f3e9] rounded-lg p-2 w-full"
                type="tel"
                name="phone"
                value={formData.phone}
                onChange={handleInputChange}
                placeholder="Your phone number"
              />
            </div>
            <div className="mb-4">
              <label className="block text-gray-700 text-sm font-bold mb-2">
                Message:
              </label>
              <input
                className="bg-[#e8f3e9] rounded-lg p-2 w-full"
                type="text"
                name="message"
                value={formData.message}
                onChange={handleInputChange}
                placeholder="Your message"
              />
            </div>
            <div className="flex justify-center">
              <button
                className="bg-[#18e719] rounded-lg px-4 py-2"
                onClick={handleSendMessage}
              >
                Send Message
              </button>
            </div>
          </form>
          <ToastContainer />
          {messageSent && (
            <div className="flex items-center justify-center mt-4">
              <p className="text-green-600">Request sent!</p>
            </div>
          )}
        </div>
      </div>
    </>
  );
}
